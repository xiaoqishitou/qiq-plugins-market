# Pi 智能助手（qiq 插件）

把 QQ 群聊 / 私聊消息接到 [Pi](https://github.com/earendil-works/pi) coding agent 上：
群里 @ 机器人（或发指定前缀）→ 交给 Pi → 把回答发回 QQ。

- 插件 Id：`pi-agent`
- 目标框架：`.NET 8`（`net8.0`），只依赖 `Qiq.Plugin.Sdk`
- 传输方式：`pi --mode rpc` 长连接子进程，严格 JSONL，按 `agent_settled` 判定完成
- 会话隔离：**每个群 / 每个私聊在 Pi 里各有一条独立 session**，上下文互不串
- 一个插件实例（一个 QQ 账号）对应一个 Pi 子进程；插件停用/卸载时自动关闭

---

## 1. 安装

把整个 `pi-agent` 目录放进 qiq 的插件目录：

```
<qiq 安装目录>\plugins\pi-agent\
    QiqPiPlugin.dll
    QiqPiPlugin.deps.json
    plugin.json
    README.md
```

重启 qiq（或插件页热重载）→ 在插件列表里找到「Pi 智能助手」→ 授权
（读取消息 / 发送消息 / 存储 / 网络 / 文件系统）→ 启用 → 填配置。

环境要求：

- Node.js **≥ 22.19**（Pi 的硬性要求；`node --version` 确认）
- 已安装 `@earendil-works/pi-coding-agent`（`npm i -g @earendil-works/pi-coding-agent`），
  或已有一份解压好的 `dist/bundle/cli.js`
- 一个可用的模型：Pi 自带的 `/login` 凭据，或在插件里填 `BaseUrl + ApiKey + Model`

---

## 2. 最少要填的配置

### 方案 A：复用本机 Pi 的登录凭据

先在本机跑一次 `pi`，用 `/login` 登录（或设置对应的环境变量），然后插件里只填：

| 字段 | 值 |
|---|---|
| Pi CLI 路径 | `C:\…\node_modules\@earendil-works\pi-coding-agent\dist\bundle\cli.js` |
| 模型 | 留空（用 Pi 默认），或 `anthropic/claude-sonnet-5` 这种 `provider/id` |

### 方案 B：在插件里直接配 OpenAI 兼容网关（推荐发给别人用）

| 字段 | 示例 |
|---|---|
| Pi CLI 路径 | `C:\…\dist\bundle\cli.js` |
| 接口地址 BaseUrl | `https://api.deepseek.com/v1` |
| 接口协议 | `openai-completions`（DeepSeek / 硅基流动 / vLLM 等） |
| API Key | `sk-…` |
| 模型 | `deepseek-chat` |
| 上下文窗口 | `128000`（按模型实际值） |

插件会在自己的数据目录生成 `pi-agent\models.json`（provider 名固定为 `qiq`），
不会改动你 `~/.pi/agent` 里的任何东西。

### 方案 C：本机有 Responses 网关

| 字段 | 示例 |
|---|---|
| BaseUrl | `http://127.0.0.1:3425/v1` |
| 接口协议 | `openai-responses` |
| API Key | 网关要求的 token（本地网关可随便填） |
| 模型 | `auto/deepseek-v4.1-flash` |

> 本插件已在 Pi 1.6.1 + Node 24.17 + 本地 Responses 网关上跑通：
> 群聊 @ 触发、上下文记忆、`/new` 清空、私聊回复、4 秒超时 abort 均验证通过。

---

## 3. 怎么触发

| 场景 | 规则 |
|---|---|
| 群聊 | 默认 **@机器人** 才触发；填了「触发前缀」后，前缀开头的消息也触发 |
| 私聊 | 直接发消息就触发 |
| 白名单 | 「允许的群」「允许的用户」留空 = 不限制；填了只对列表生效 |
| 冷却 | 同一个 QQ 号默认 2 秒内只处理一条，防刷屏 |
| 排队 | 默认最多 8 条排队，超过直接回「忙」 |

触发后插件把消息整理成：

```
[群「测试群」] 张三(123456)：帮我写个正则
```

（可在配置里关掉「附带发送者昵称」。）图片会作为视觉输入一起交给 Pi
（http 链接或本地文件，单张 ≤ 4MB，最多 2 张；模型需要支持图片）。

## 4. 指令

指令前缀默认 `/`（可改，留空 = 关闭指令）：

| 指令 | 作用 |
|---|---|
| `/new`、`/reset` | 为当前群/私聊开新会话，清空上下文 |
| `/status` | 进程、模型、队列、会话、最后错误 |
| `/abort`、`/stop` | 中断正在生成的回答 |
| `/model` | 查看当前模型 |
| `/model provider/id` | 切换模型（群里仅群主/管理员可用） |
| `/help` | 帮助 |
| `/ping` | 连通性测试 |

---

## 5. 配置字段

| 字段 | 说明 |
|---|---|
| Pi CLI 路径 | `cli.js` 的绝对路径；留空会尝试常见 npm 全局路径 |
| Node 路径 | 留空 = PATH 里的 `node` |
| 工作目录 | Pi 的工作目录；留空 = 插件数据目录 `workspace` |
| Pi 配置目录 | 对应 `PI_CODING_AGENT_DIR`；填了 BaseUrl 时忽略 |
| 附加启动参数 | 追加到命令行，如 `--no-mcp` |
| BaseUrl / 接口协议 / API Key / 模型 | 自定义网关四件套，见上文 |
| 思考等级 | `off/minimal/low/medium/high/xhigh/max`，留空用 Pi 默认 |
| 网络代理 | 给 Pi 子进程设 `HTTP(S)_PROXY`，如 `http://127.0.0.1:7999` |
| 离线模式 | 加 `--offline`，禁止启动期联网（模型请求不受影响） |
| 禁用工具 | 加 `--no-tools`，Pi 只聊天不读写文件/执行命令（默认开） |
| 附加系统提示词 | 追加到 Pi 系统提示词 |
| 上下文窗口 / 最大输出 | 写进 `models.json` 的 `contextWindow` / `maxTokens` |
| 群聊 @ 触发 / 触发前缀 | 见「怎么触发」 |
| 允许的群 / 允许的用户 | 一行一个号码，留空不限制 |
| 用户冷却 / 排队上限 | 防刷屏 |
| 超时 / 等待提示 | 超时后 abort 并把已生成内容发回；等待提示 0 = 关闭 |
| 单条字数上限 / 最多拆几条 | QQ 长消息自动拆条 |
| 附带发送者昵称 / 显示工具调用 / 识别图片 | 输出细节开关 |
| 指令前缀 | 默认 `/` |

---

## 6. 排错

| 现象 | 处理 |
|---|---|
| `Pi 启动失败：找不到 Pi CLI` | 填绝对路径，注意 `cli.js` 不是 `pi.cmd` |
| `spawn node ENOENT` | 装 Node ≥ 22.19，或在「Node 路径」填 `node.exe` 全路径 |
| `401 / Incorrect API key` | BaseUrl 与 Key 不匹配；或本机环境变量里的旧 Key 干扰，改用方案 B 的独立配置 |
| 一直「⏰ 超时」 | 网关不通/需要代理；填「网络代理」；或先用 `pi` 命令行确认模型可用 |
| 回答很慢 | 换更快的模型；`/status` 看模型与队列 |
| 群里 @ 没反应 | 确认机器人已启用、权限已授权、群号没被白名单排除、@ 的是机器人本体 |
| 想让它读文件/执行命令 | 关闭「禁用工具」，并按 Pi 的安全设置配置审批；默认关闭是有意为之 |
| 会话想彻底重来 | 发 `/new`；或删掉插件数据目录里的 `sessions\*.jsonl` |

插件日志前缀是 `[pi]`，Pi 自己的 stderr 以 `[pi@<账号>] pi:` 记在 Debug 级别。

---

## 7. 构建与自测

```powershell
# 插件本体（要求 0 警告 0 错误）
dotnet build .\QiqPiPlugin.csproj -c Release

# RPC / 会话隔离 / 超时
dotnet run --project .\harness\PiHarness.csproj -c Release
dotnet run --project .\harness\PiHarness.csproj -c Release -- --timeout

# 插件加载 + 配置字段
dotnet run --project .\harness\PluginProbe.csproj -c Release

# 端到端（假 QQ 上下文 → 真 Pi → 捕获回复）
dotnet run --project .\harness\EventHarness.csproj -c Release
```

`EventHarness` 会用 `harness` 里写死的本地网关配置，跑之前按需改成你自己的
`PiCliPath / BaseUrl / ApiKey / Model`。

---

## 8. 目录

```
QiqPiPlugin.csproj
plugin.json
src/
  QiqPiPlugin.cs     事件路由、指令、会话映射、拆条发送
  PiProcess.cs       Pi 子进程 + JSONL RPC 客户端（id 关联 / agent_settled / abort）
  PiSettings.cs      配置 POCO（ConfigField）
  MediaInbox.cs      QQ 图片 → base64
harness/
  PiHarness.cs       RPC + 跨会话记忆 + 超时
  EventHarness.cs    假 qiq 上下文跑完整插件链路
  PluginProbe.cs     扫描 dll、校验 ABI、列出配置字段
```

## 9. 已知边界

- 一个账号一个 Pi 进程，prompt 串行；多个群同时说话会排队（默认上限 8 条）。
- 会话文件会一直保留（在插件数据目录 `sessions\`），需要清理时手动删。
- 工具默认禁用；开启后 Pi 的工具审批在 QQ 里无法点击，插件会自动取消弹窗，
  所以请只在你信任的工作目录 / 模型下开启工具。
- QQ 图片需要可公开访问或本机可读；带鉴权的临时链接可能读不到（会提示「未能读取」）。
